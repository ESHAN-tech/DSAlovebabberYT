# C-programs
here i have done a quetions practice of dsa using c++
